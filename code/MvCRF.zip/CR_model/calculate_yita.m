clear all
% 已知的向量，替换...为向量中的实际值
b = xlsread('b_2023_9.xlsx');

disp(b)

% 定义概率密度函数
pdf = @(x) 1/sqrt(2*pi) * exp(-x.^2/2);

% 定义方程
equation = @(x) arrayfun(@(y) integral(@(t) pdf(t), -Inf, y), x) - b;

% 使用 fsolve 求解方程，初始猜测值为长度为 50 的零向量
initial_guess = zeros(size(b));

% 调用 fsolve 求解方程
solution = fsolve(equation, initial_guess, optimset('Display', 'off'));

xlswrite('yita_2023_9',solution)

disp('方程的解：');
disp(solution);
