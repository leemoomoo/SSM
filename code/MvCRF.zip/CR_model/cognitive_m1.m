function alpha=cognitive_m1(a2,d211,d212,d221,d222,theta,yita)
stu_num=length(theta);
knw_num=length(a2);
%%%%%%%%%%%%%% ���Ʋ���
a2_cop=repmat(a2,stu_num,1);%��w1��ֵ������466�и�a2_cop
d211_cop=repmat(d211,stu_num,1);%theta��һ��ֵ
d212_cop=repmat(d212,stu_num,1);%yita��һ��ֵ
d221_cop=repmat(d221,stu_num,1);%theta�ڶ���ֵ
d222_cop=repmat(d222,stu_num,1);%yita�ڶ���ֵ
theta_cop=repmat(theta',1,knw_num);
yita_cop=repmat(yita',1,knw_num);
%%%%%%%%%%%%%%%%%%%%%%
lambda_theta=1./(1+(1-a2_cop).*exp(-1.7*(yita_cop-d222_cop)));
lambda_yita=1./(1+a2_cop.*exp(-1.7*(theta_cop-d221_cop)));
alpha_theta=a2_cop./(1+exp(-1.7*(theta_cop-d211_cop)));
alpha_yita=(1-a2_cop)./(1+exp(-1.7*(yita_cop-d212_cop)));
alpha=(lambda_theta.*alpha_theta+lambda_yita.*alpha_yita);
%alpha=(alpha-repmat(mean(alpha,1),stu_num,1))./(repmat(std(alpha,1,1),stu_num,1));
end